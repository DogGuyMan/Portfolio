const nodemailer = require("nodemailer");

const email = {
    "host" : ""
}